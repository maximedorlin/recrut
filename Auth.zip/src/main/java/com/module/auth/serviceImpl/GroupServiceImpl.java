package com.module.auth.serviceImpl;

import com.module.auth.dto.GroupDTO;
import com.module.auth.entity.Group;
import com.module.auth.entity.Permission;
import com.module.auth.exception.AuthException;
import com.module.auth.repository.GroupRepository;
import com.module.auth.repository.PermissionRepository;
import com.module.auth.service.GroupService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class GroupServiceImpl implements GroupService {

    private final GroupRepository groupRepository;
    private final PermissionRepository permissionRepository;

    @Override
    public Group createGroup(GroupDTO groupDTO) {
        if (groupRepository.existsByName(groupDTO.getName())) {
            throw new AuthException("Group name already exists");
        }

        Group group = new Group();
        group.setName(groupDTO.getName());
        return groupRepository.save(group);
    }

    @Override
    public List<Group> getAllGroups() {
        return groupRepository.findAll();
    }

    @Override
    public Group getGroupById(Long id) {
        return groupRepository.findById(id)
                .orElseThrow(() -> new AuthException("Group not found"));
    }

    @Override
    public Group updateGroup(Long id, GroupDTO groupDTO) {
        Group group = getGroupById(id);
        group.setName(groupDTO.getName());
        return groupRepository.save(group);
    }

    @Override
    public void deleteGroup(Long id) {
        Group group = getGroupById(id);
        groupRepository.delete(group);
    }

    @Override
    public void addPermissionToGroup(Long groupId, Long permissionId) {
        Group group = getGroupById(groupId);
        Permission permission = permissionRepository.findById(permissionId)
                .orElseThrow(() -> new AuthException("Permission not found"));
        group.getPermissions().add(permission);
        groupRepository.save(group);
    }

    @Override
    public void removePermissionFromGroup(Long groupId, Long permissionId) {
        Group group = getGroupById(groupId);
        Permission permission = permissionRepository.findById(permissionId)
                .orElseThrow(() -> new AuthException("Permission not found"));
        group.getPermissions().remove(permission);
        groupRepository.save(group);
    }

    @Override
    public List<Permission> getGroupPermissions(Long groupId) {
        Group group = getGroupById(groupId);
        return List.copyOf(group.getPermissions()); // Retourne une liste non modifiable
    }
}