package com.module.auth.serviceImpl;

import com.module.auth.dto.PermissionDTO;
import com.module.auth.entity.Permission;
import com.module.auth.exception.AuthException;
import com.module.auth.repository.PermissionRepository;
import com.module.auth.service.PermissionService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class PermissionServiceImpl implements PermissionService {

    private final PermissionRepository permissionRepository;

    @Override
    public List<PermissionDTO> getAllPermissions() {
        return permissionRepository.findAll().stream()
                .map(this::mapToDTO)
                .collect(Collectors.toList());
    }

    @Override
    public Permission createPermission(PermissionDTO permissionDTO) {
        if (permissionRepository.existsByName(permissionDTO.getName()) ||
                permissionRepository.existsByCode(permissionDTO.getCode())) {
            throw new AuthException("Permission name or code already exists");
        }

        Permission permission = new Permission();
        permission.setName(permissionDTO.getName());
        permission.setCode(permissionDTO.getCode());
        return permissionRepository.save(permission);
    }

    @Override
    public Permission getPermissionById(Long id) {
        return permissionRepository.findById(id)
                .orElseThrow(() -> new AuthException("Permission not found"));
    }

    @Override
    public Permission updatePermission(Long id, PermissionDTO permissionDTO) {
        Permission permission = getPermissionById(id);
        permission.setName(permissionDTO.getName());
        permission.setCode(permissionDTO.getCode());
        return permissionRepository.save(permission);
    }

    @Override
    public void deletePermission(Long id) {
        Permission permission = getPermissionById(id);
        permissionRepository.delete(permission);
    }

    private PermissionDTO mapToDTO(Permission permission) {
        PermissionDTO dto = new PermissionDTO();
        dto.setId(permission.getId());
        dto.setName(permission.getName());
        dto.setCode(permission.getCode());
        return dto;
    }
}