package com.module.auth.serviceImpl;

import com.module.auth.entity.User;
import com.module.auth.repository.UserRepository;
import com.module.auth.security.CustomUserDetails;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;


@Service
public class UserDetailsServiceImpl implements UserDetailsService {

    private final UserRepository userRepository;

    @Autowired
    public UserDetailsServiceImpl(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    // @Override
    // public UserDetails loadUserByUsername(String email) throws UsernameNotFoundException {
    //     User user = userRepository.findByEmail(email)
    //             .orElseThrow(() -> new UsernameNotFoundException("User not found with email: " + email));
        
    //     // Debugging log - remove in production
    //     System.out.println("Loaded user: " + user.getEmail() + 
    //                       " Active: " + user.isActive() + 
    //                       " Password: " + user.getPassword());
        
    //     return new org.springframework.security.core.userdetails.User(
    //             user.getEmail(),
    //             user.getPassword(),
    //             user.isActive(),          // enabled
    //             true,                     // accountNonExpired
    //             true,                     // credentialsNonExpired
    //             true,                     // accountNonLocked
    //             getAuthorities(user.getGroup())
    //     );
    // }

    @Override
public UserDetails loadUserByUsername(String email) throws UsernameNotFoundException {
    User user = userRepository.findByEmail(email)
        .orElseThrow(() -> new UsernameNotFoundException("User not found with email: " + email));
    return new CustomUserDetails(user);
}

    // private Collection<? extends GrantedAuthority> getAuthorities(Group group) {
    //     // Handle case where user has no group
    //     if (group == null) {
    //         return Collections.emptyList();
    //     }
        
    //     // Convert group roles to authorities
    //     // Assuming Group has a 'name' or 'roles' field
    //     return Collections.singletonList(
    //         new SimpleGrantedAuthority("ROLE_" + group.getName().toUpperCase())
    //     );
    // }
}