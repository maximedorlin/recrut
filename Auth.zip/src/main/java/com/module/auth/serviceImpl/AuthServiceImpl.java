package com.module.auth.serviceImpl;

import com.module.auth.dto.*;
import com.module.auth.entity.*;
import com.module.auth.exception.AuthException;
import com.module.auth.repository.*;
import com.module.auth.security.JwtTokenProvider;
import com.module.auth.service.AuthService;
import com.module.auth.service.SessionService;

import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;

import org.springframework.http.HttpStatus;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;

@Service
@RequiredArgsConstructor
public class AuthServiceImpl implements AuthService {

    private final UserRepository userRepository;
    private final GroupRepository groupRepository;
    private final SessionRepository sessionRepository;
    private final PasswordEncoder passwordEncoder;
    private final AuthenticationManager authenticationManager;
    private final JwtTokenProvider tokenProvider;
    private final JavaMailSender mailSender;
    private final SessionService sessionService;

    // Méthode pour obtenir la requête HTTP actuelle
    private HttpServletRequest getCurrentRequest() {
        return (HttpServletRequest) SecurityContextHolder.getContext()
                .getAuthentication()
                .getDetails();
    }

    @Override
    @Transactional
    public AuthResponse login(LoginRequest request) {
        try {
            Authentication authentication = authenticationManager.authenticate(
                    new UsernamePasswordAuthenticationToken(
                            request.getEmail(),
                            request.getPassword()));

            SecurityContextHolder.getContext().setAuthentication(authentication);

            User user = userRepository.findByEmail(request.getEmail())
                    .orElseThrow(() -> new AuthException("User not found", HttpStatus.UNAUTHORIZED));

            Session session = sessionService.createSession(user, getCurrentRequest());
            sessionRepository.save(session);

            // Générer les deux tokens
            String accessToken = tokenProvider.generateAccessToken(user);
            String refreshToken = tokenProvider.generateRefreshToken(user);

            return new AuthResponse(accessToken, refreshToken);
        } catch (org.springframework.security.core.AuthenticationException e) {
            throw new AuthException("Invalid credentials", HttpStatus.UNAUTHORIZED);
        }
        // } catch (AuthenticationException e) {
        // throw new AuthException("Invalid credentials", HttpStatus.UNAUTHORIZED);
        // }
    }

    @Override
    @Transactional
    public AuthResponse register(RegisterRequest request) {
        if (userRepository.existsByEmail(request.getEmail())) {
            throw new AuthException("Email déjà utilisé");
        }

        User user = new User();
        user.setEmail(request.getEmail());
        user.setPassword(passwordEncoder.encode(request.getPassword()));
        user.setFirstName(request.getFirstName());
        user.setLastName(request.getLastName());
        user.setPhoneNumber(request.getPhoneNumber());

        // Assigner le groupe par défaut
        Group defaultGroup = groupRepository.findByName("USER")
                .orElseThrow(() -> new AuthException("Groupe par défaut non trouvé"));
        user.setGroup(defaultGroup);

        User savedUser = userRepository.save(user);

        // Envoyer l'email de bienvenue
        sendWelcomeEmail(savedUser);

        // Générer les tokens
        return generateAuthResponse(savedUser);
    }

    @Override
    public AuthResponse refreshToken(RefreshTokenRequest request) {
        if (!tokenProvider.validateToken(request.getRefreshToken())) {
            throw new AuthException("Token de rafraîchissement invalide", HttpStatus.UNAUTHORIZED);
        }

        String email = tokenProvider.getUsernameFromToken(request.getRefreshToken());
        User user = userRepository.findByEmail(email)
                .orElseThrow(() -> new AuthException("Utilisateur non trouvé", HttpStatus.NOT_FOUND));

        return generateAuthResponse(user);
    }

    @Override
    public void forgotPassword(ForgotPasswordRequest request) {
        User user = userRepository.findByEmail(request.getEmail())
                .orElseThrow(() -> new AuthException("Email non trouvé"));

        String resetToken = tokenProvider.generatePasswordResetToken(user);
        sendResetPasswordEmail(user, resetToken);
    }

    @Override
    public void logout(String refreshToken) {
        String email = tokenProvider.getUsernameFromToken(refreshToken);
        userRepository.findByEmail(email).ifPresent(user -> {
            sessionRepository.deleteByUser(user);
        });
    }

    @Override
    @Transactional
    public void resetPassword(ResetPasswordRequest request) {
        if (!request.getNewPassword().equals(request.getConfirmPassword())) {
            throw new AuthException("Les mots de passe ne correspondent pas", HttpStatus.BAD_REQUEST);
        }

        if (!tokenProvider.validateToken(request.getToken())) {
            throw new AuthException("Token invalide ou expiré", HttpStatus.UNAUTHORIZED);
        }

        String email = tokenProvider.getUsernameFromToken(request.getToken());
        User user = userRepository.findByEmail(email)
                .orElseThrow(() -> new AuthException("Token invalide", HttpStatus.UNAUTHORIZED));

        user.setPassword(passwordEncoder.encode(request.getNewPassword()));
        userRepository.save(user);

        // Invalider toutes les sessions existantes
        sessionRepository.deleteByUser(user);
    }

    @Override
    public void sendOtp(String email) {
        User user = userRepository.findByEmail(email)
                .orElseThrow(() -> new AuthException("Email non trouvé"));

        String otp = generateOtp();
        user.setOtpSecret(otp);
        userRepository.save(user);

        sendOtpEmail(user, otp);
    }

    @Override
    public boolean verifyOtp(String email, String otp) {
        User user = userRepository.findByEmail(email)
                .orElseThrow(() -> new AuthException("Email non trouvé", HttpStatus.NOT_FOUND));

        if (otp.equals(user.getOtpSecret())) {
            user.setOtpSecret(null); // Invalider l'OTP après utilisation
            userRepository.save(user);
            return true;
        }
        return false;
    }

    // private AuthResponse generateAuthResponse(User user) {
    // String accessToken = tokenProvider.generateAccessToken(user);
    // String refreshToken = tokenProvider.generateRefreshToken(user);
    // return new AuthResponse(accessToken, refreshToken);
    // }

    private AuthResponse generateAuthResponse(User user) {
        String accessToken = tokenProvider.generateAccessToken(user);
        String refreshToken = tokenProvider.generateRefreshToken(user);

        return new AuthResponse(
                accessToken,
                user.getId(),
                user.getFirstName(),
                user.getLastName(),
                user.getEmail(),
                user.getPhoneNumber(),
                tokenProvider.getJwtAccessExpiration() // Méthode à ajouter dans JwtTokenProvider
        );
    }

    private void sendWelcomeEmail(User user) {
        SimpleMailMessage message = new SimpleMailMessage();
        message.setTo(user.getEmail());
        message.setSubject("Bienvenue sur notre plateforme");
        message.setText("Bonjour " + user.getFirstName() + ",\n\nMerci pour votre inscription !");
        mailSender.send(message);
    }

    private void sendResetPasswordEmail(User user, String token) {
        String resetLink = "http://localhost:8080/api/auth/reset-password?token=" + token;

        SimpleMailMessage message = new SimpleMailMessage();
        message.setTo(user.getEmail());
        message.setSubject("Réinitialisation de votre mot de passe");
        message.setText("Pour réinitialiser votre mot de passe, cliquez sur ce lien : " + resetLink);
        mailSender.send(message);
    }

    private void sendOtpEmail(User user, String otp) {
        SimpleMailMessage message = new SimpleMailMessage();
        message.setTo(user.getEmail());
        message.setSubject("Votre code de vérification");
        message.setText("Votre code OTP est : " + otp);
        mailSender.send(message);
    }

    private String generateOtp() {
        return String.valueOf(new Random().nextInt(899999) + 100000);
    }

    @Override
    public void changePassword(ChangePasswordRequest request, String email) {
        User user = userRepository.findByEmail(email)
                .orElseThrow(() -> new AuthException("Utilisateur non trouvé"));

        if (!passwordEncoder.matches(request.getOldPassword(), user.getPassword())) {
            throw new AuthException("Ancien mot de passe incorrect");
        }

        if (!request.getNewPassword().equals(request.getConfirmPassword())) {
            throw new AuthException("Les mots de passe ne correspondent pas");
        }

        user.setPassword(passwordEncoder.encode(request.getNewPassword()));
        userRepository.save(user);
    }

    @Override
    public UserProfileDTO getUserProfile(String email) {
        User user = userRepository.findByEmail(email)
                .orElseThrow(() -> new AuthException("Utilisateur non trouvé"));
        return mapToUserProfileDTO(user);
    }

    private UserProfileDTO mapToUserProfileDTO(User user) {
        UserProfileDTO dto = new UserProfileDTO();
        dto.setId(user.getId());
        dto.setEmail(user.getEmail());
        dto.setFirstName(user.getFirstName());
        dto.setLastName(user.getLastName());
        dto.setPhoneNumber(user.getPhoneNumber());
        // ... autres champs
        return dto;
    }

}
