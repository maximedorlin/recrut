package com.module.auth.controller;

import com.module.auth.dto.GroupDTO;
import com.module.auth.dto.PermissionDTO;
import com.module.auth.entity.Group;
import com.module.auth.entity.Permission;
import com.module.auth.service.GroupService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/groups")
@RequiredArgsConstructor
public class GroupController {

    private final GroupService groupService;

    @PostMapping
    public ResponseEntity<GroupDTO> createGroup(@RequestBody GroupDTO groupDTO) {
        Group group = groupService.createGroup(groupDTO);
        return ResponseEntity.ok(mapToDTO(group));
    }

    @GetMapping
    public ResponseEntity<List<GroupDTO>> getAllGroups() {
        List<Group> groups = groupService.getAllGroups();
        return ResponseEntity.ok(groups.stream().map(this::mapToDTO).collect(Collectors.toList()));
    }

    @GetMapping("/{id}")
    public ResponseEntity<GroupDTO> getGroupById(@PathVariable Long id) {
        Group group = groupService.getGroupById(id);
        return ResponseEntity.ok(mapToDTO(group));
    }

    @PutMapping("/{id}")
    public ResponseEntity<GroupDTO> updateGroup(
            @PathVariable Long id, 
            @RequestBody GroupDTO groupDTO) {
        Group group = groupService.updateGroup(id, groupDTO);
        return ResponseEntity.ok(mapToDTO(group));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteGroup(@PathVariable Long id) {
        groupService.deleteGroup(id);
        return ResponseEntity.noContent().build();
    }

    @PostMapping("/{groupId}/permissions/{permissionId}")
    public ResponseEntity<Void> addPermissionToGroup(
            @PathVariable Long groupId, 
            @PathVariable Long permissionId) {
        groupService.addPermissionToGroup(groupId, permissionId);
        return ResponseEntity.ok().build();
    }

    @DeleteMapping("/{groupId}/permissions/{permissionId}")
    public ResponseEntity<Void> removePermissionFromGroup(
            @PathVariable Long groupId, 
            @PathVariable Long permissionId) {
        groupService.removePermissionFromGroup(groupId, permissionId);
        return ResponseEntity.ok().build();
    }

    @GetMapping("/{groupId}/permissions")
    public ResponseEntity<List<PermissionDTO>> getGroupPermissions(@PathVariable Long groupId) {
        List<Permission> permissions = groupService.getGroupPermissions(groupId);
        return ResponseEntity.ok(
            permissions.stream()
                .map(this::mapPermissionToDTO)
                .collect(Collectors.toList())
        );
    }

    private GroupDTO mapToDTO(Group group) {
        GroupDTO dto = new GroupDTO();
        dto.setId(group.getId());
        dto.setName(group.getName());
        dto.setPermissions(
            group.getPermissions().stream()
                .map(this::mapPermissionToDTO)
                .collect(Collectors.toSet())
        );
        return dto;
    }

    private PermissionDTO mapPermissionToDTO(Permission permission) {
        PermissionDTO dto = new PermissionDTO();
        dto.setId(permission.getId());
        dto.setName(permission.getName());
        dto.setCode(permission.getCode());
        return dto;
    }
}
