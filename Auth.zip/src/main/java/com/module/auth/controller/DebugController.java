package com.module.auth.controller;

import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.module.auth.entity.User;
import com.module.auth.repository.UserRepository;

// Add this temporary debug endpoint to check password encoding
@RestController
public class DebugController {

    private final PasswordEncoder passwordEncoder;
    private final UserRepository userRepository;

    public DebugController(PasswordEncoder passwordEncoder, UserRepository userRepository) {
        this.passwordEncoder = passwordEncoder;
        this.userRepository = userRepository;
    }

    @GetMapping("/debug/password")
    public String debugPassword(@RequestParam String email, @RequestParam String rawPassword) {
        User user = userRepository.findByEmail(email)
                .orElseThrow(() -> new RuntimeException("User not found"));
        
        boolean matches = passwordEncoder.matches(rawPassword, user.getPassword());
        
        return "Password matches: " + matches + "\n" +
               "Stored hash: " + user.getPassword() + "\n" +
               "Encoded input: " + passwordEncoder.encode(rawPassword);
    }
}