package com.module.auth.repository;

import com.module.auth.entity.Session;
import com.module.auth.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface SessionRepository extends JpaRepository<Session, Long> {
    List<Session> findByUserAndActiveTrue(User user);

    List<Session> findByUser(User user);

    void deleteByUser(User user); // Correction : retourne void
}