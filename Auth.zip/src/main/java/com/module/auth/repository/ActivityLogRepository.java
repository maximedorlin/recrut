package com.module.auth.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.module.auth.entity.ActivityLog;

public interface ActivityLogRepository extends JpaRepository<ActivityLog, Long> {
   
}