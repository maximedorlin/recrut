package com.module.auth.entity;

import lombok.Data;
import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Data
@Table(name = "sessions")
public class Session {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "user_id", nullable = false)
    private User user;

    @Column(name = "connection_date")
    private LocalDateTime connectionDate = LocalDateTime.now(); // Utiliser LocalDateTime

    @Column(name = "is_active")
    private boolean active = true;
    private String platform;
    private String appName;
    private String appVersion;
    private String appCodeName;
    private String userAgent;
    
    @Column(name = "ip_address")
    private String ipAddress;

    public void closeSession() {
        this.active = false;
    }
}
