package com.module.auth.entity;

import lombok.Data;
import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Data
@Table(name = "activity_logs")
public class ActivityLog {
    // @Id
    // @GeneratedValue(strategy = GenerationType.AUTO)
    // @Column(columnDefinition = "uuid", updatable = false, nullable = false)
    // private UUID id;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "user_id", nullable = false)
    private User user;

    private String action;
    private String method;
    private LocalDateTime timestamp = LocalDateTime.now();
}
