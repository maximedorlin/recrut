package com.module.auth.service;

import com.module.auth.dto.PermissionDTO;
import com.module.auth.entity.Permission;

import java.util.List;

public interface PermissionService {
    List<PermissionDTO> getAllPermissions();
    Permission createPermission(PermissionDTO permissionDTO);
    Permission getPermissionById(Long id);
    Permission updatePermission(Long id, PermissionDTO permissionDTO);
    void deletePermission(Long id);
}