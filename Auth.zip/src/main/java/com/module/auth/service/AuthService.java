package com.module.auth.service;

import com.module.auth.dto.*;

public interface AuthService {
    AuthResponse register(RegisterRequest request);
    AuthResponse login(LoginRequest request);
    AuthResponse refreshToken(RefreshTokenRequest request);
    void logout(String refreshToken);
    void forgotPassword(ForgotPasswordRequest request);
    void resetPassword(ResetPasswordRequest request);
    void sendOtp(String email);
    boolean verifyOtp(String email, String otp);
    void changePassword(ChangePasswordRequest request, String email);
    UserProfileDTO getUserProfile(String email);
}
