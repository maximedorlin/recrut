// package com.module.auth.service;

// import com.module.auth.entity.Session;
// import com.module.auth.entity.User;
// import com.module.auth.repository.SessionRepository;
// import jakarta.servlet.http.HttpServletRequest;
// import org.springframework.stereotype.Service;

// import java.time.LocalDateTime;

// @Service
// public class SessionService {

//     private final SessionRepository sessionRepository;

//     public SessionService(SessionRepository sessionRepository) {
//         this.sessionRepository = sessionRepository;
//     }

//     public Session createSession(User user, HttpServletRequest request) {
//         // Fermer les sessions actives existantes
//         sessionRepository.findByUserAndActiveTrue(user).forEach(session -> {
//             session.setActive(false);
//             sessionRepository.save(session);
//         });

//         // Créer une nouvelle session
//         Session newSession = new Session();
//         newSession.setUser(user);
//         newSession.setActive(true);
//         newSession.setConnectionDate(LocalDateTime.now());
//         newSession.setIpAddress(getClientIp(request));
//         newSession.setUserAgent(request.getHeader("User-Agent"));
        
//         // Vous pouvez ajouter plus d'informations ici
//         newSession.setPlatform("Web");
//         newSession.setAppName("YourAppName");
//         newSession.setAppVersion("1.0.0");
        
//         return sessionRepository.save(newSession);
//     }

//     private String getClientIp(HttpServletRequest request) {
//         String ip = request.getHeader("X-Forwarded-For");
//         if (ip == null || ip.isEmpty() || "unknown".equalsIgnoreCase(ip)) {
//             ip = request.getHeader("Proxy-Client-IP");
//         }
//         if (ip == null || ip.isEmpty() || "unknown".equalsIgnoreCase(ip)) {
//             ip = request.getHeader("WL-Proxy-Client-IP");
//         }
//         if (ip == null || ip.isEmpty() || "unknown".equalsIgnoreCase(ip)) {
//             ip = request.getRemoteAddr();
//         }
//         return ip;
//     }
// }


package com.module.auth.service;

import com.module.auth.entity.Session;
import com.module.auth.entity.User;
import com.module.auth.repository.SessionRepository;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.time.LocalDateTime;

@Service
public class SessionService {

    private final SessionRepository sessionRepository;

    public SessionService(SessionRepository sessionRepository) {
        this.sessionRepository = sessionRepository;
    }

    @Transactional
    public Session createSession(User user, HttpServletRequest request) {
        // Fermer les sessions actives existantes
        sessionRepository.findByUserAndActiveTrue(user).forEach(session -> {
            session.setActive(false);
            sessionRepository.save(session);
        });

        // Créer une nouvelle session
        Session newSession = new Session();
        newSession.setUser(user);
        newSession.setActive(true);
        newSession.setConnectionDate(LocalDateTime.now());
        newSession.setIpAddress(getClientIp(request));
        newSession.setUserAgent(request.getHeader("User-Agent"));
        
        // Informations supplémentaires
        newSession.setPlatform("Web");
        newSession.setAppName("YourAppName");
        newSession.setAppVersion("1.0.0");
        
        return sessionRepository.save(newSession);
    }

    private String getClientIp(HttpServletRequest request) {
        String ip = request.getHeader("X-Forwarded-For");
        if (ip == null || ip.isEmpty() || "unknown".equalsIgnoreCase(ip)) {
            ip = request.getHeader("Proxy-Client-IP");
        }
        if (ip == null || ip.isEmpty() || "unknown".equalsIgnoreCase(ip)) {
            ip = request.getHeader("WL-Proxy-Client-IP");
        }
        if (ip == null || ip.isEmpty() || "unknown".equalsIgnoreCase(ip)) {
            ip = request.getRemoteAddr();
        }
        return ip;
    }
}