package com.module.auth.service;

import com.module.auth.dto.GroupDTO;
import com.module.auth.entity.Group;
import com.module.auth.entity.Permission;

import java.util.List;

public interface GroupService {
    Group createGroup(GroupDTO groupDTO);
    List<Group> getAllGroups();
    Group getGroupById(Long id);
    Group updateGroup(Long id, GroupDTO groupDTO);
    void deleteGroup(Long id);
    void addPermissionToGroup(Long groupId, Long permissionId);
    void removePermissionFromGroup(Long groupId, Long permissionId);
    List<Permission> getGroupPermissions(Long groupId);
}