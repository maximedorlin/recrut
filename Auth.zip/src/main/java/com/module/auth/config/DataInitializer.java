package com.module.auth.config;

import com.module.auth.entity.Group;
import com.module.auth.entity.User;
import com.module.auth.repository.GroupRepository;
import com.module.auth.repository.UserRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.crypto.password.PasswordEncoder;

@Configuration
public class DataInitializer {

    @Bean
    CommandLineRunner initUsers(UserRepository userRepository,
                                GroupRepository groupRepository,
                                PasswordEncoder passwordEncoder) {
        return args -> {
            String defaultEmail = "admin@dno.com";
            if (userRepository.findByEmail(defaultEmail).isEmpty()) {
                Group adminGroup = groupRepository.findByName("ADMIN")
                        .orElseGet(() -> {
                            Group groupe = new Group();
                            groupe.setName("ADMIN");
                            return groupRepository.save(groupe);
                        });

                User admin = new User();
                admin.setEmail(defaultEmail);
                admin.setPassword(passwordEncoder.encode("admin123"));
                admin.setFirstName("Admin");
                admin.setLastName("User");
                admin.setActive(true);
                admin.setGroup(adminGroup);

                userRepository.save(admin);

                System.out.println("User admin créé par default.");
            } else {
                System.out.println("User admin déjà présent.");
            }
        };
    }
}
