package com.module.auth.config;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.io.IOException;
import java.text.MessageFormat;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

@Service
public class TranslationService {

    private final ResourceLoader resourceLoader;
    private final ObjectMapper objectMapper;
    private static final Logger logger = LoggerFactory.getLogger(TranslationService.class);
    
    // Cache pour stocker les messages par locale
    private final Map<String, Map<String, String>> translationCache = new ConcurrentHashMap<>();
    private static final String DEFAULT_LANGUAGE = "en";

    @Autowired
    public TranslationService(ResourceLoader resourceLoader, ObjectMapper objectMapper) {
        this.resourceLoader = resourceLoader;
        this.objectMapper = objectMapper;
        preloadDefaultTranslations();
    }

    public String getMessage(String key) {
        return getMessage(key, null);
    }

    public String getMessage(String key, Object[] args) {
        return getMessage(key, args, false);
    }

    public String getSafeMessage(String key) {
        return getSafeMessage(key, null);
    }

    public String getSafeMessage(String key, Object[] args) {
        return escapeHtml(getMessage(key, args));
    }

    private String getMessage(String key, Object[] args, boolean skipCache) {
        if (!StringUtils.hasText(key)) {
            logger.warn("Attempted to retrieve translation for empty key");
            return "";
        }

        Map<String, String> messages = loadTranslations(skipCache);
        String pattern = messages.get(key);

        if (pattern == null) {
            logger.warn("Translation key '{}' not found for locale: {}", key, getCurrentLanguage());
            return key;
        }

        return formatMessage(pattern, args);
    }

    private String formatMessage(String pattern, Object[] args) {
        try {
            if (args != null && args.length > 0) {
                return MessageFormat.format(pattern, args);
            }
            return pattern;
        } catch (IllegalArgumentException e) {
            logger.error("Error formatting message: {}", pattern, e);
            return pattern;
        }
    }

    private Map<String, String> loadTranslations(boolean skipCache) {
        String language = getCurrentLanguage();
        
        if (!skipCache && translationCache.containsKey(language)) {
            return translationCache.get(language);
        }

        String filename = "i18n/messages_" + language + ".json";
        Map<String, String> messages = new HashMap<>();

        try {
            Resource resource = resourceLoader.getResource("classpath:" + filename);
            if (resource.exists()) {
                JsonNode rootNode = objectMapper.readTree(resource.getInputStream());
                rootNode.fields().forEachRemaining(entry -> 
                    messages.put(entry.getKey(), entry.getValue().asText()));
                
                translationCache.put(language, messages);
                return messages;
            }
        } catch (IOException e) {
            logger.error("Error loading translation file: {}", filename, e);
        }

        // Fallback to default language
        if (!language.equals(DEFAULT_LANGUAGE)) {
            return loadTranslationsForLanguage(DEFAULT_LANGUAGE);
        }

        logger.error("Default translations not found for language: {}", DEFAULT_LANGUAGE);
        return messages;
    }

    private Map<String, String> loadTranslationsForLanguage(String language) {
        if (translationCache.containsKey(language)) {
            return translationCache.get(language);
        }

        String filename = "i18n/messages_" + language + ".json";
        Map<String, String> messages = new HashMap<>();

        try {
            Resource resource = resourceLoader.getResource("classpath:" + filename);
            JsonNode rootNode = objectMapper.readTree(resource.getInputStream());
            rootNode.fields().forEachRemaining(entry -> 
                messages.put(entry.getKey(), entry.getValue().asText()));
            
            translationCache.put(language, messages);
        } catch (IOException e) {
            logger.error("Error loading translation file: {}", filename, e);
        }

        return messages;
    }

    private void preloadDefaultTranslations() {
        loadTranslationsForLanguage(DEFAULT_LANGUAGE);
    }

    public void clearCache() {
        translationCache.clear();
        preloadDefaultTranslations();
    }

    private String getCurrentLanguage() {
        Locale locale = LocaleContextHolder.getLocale();
        return locale.getLanguage();
    }

    public String escapeHtml(String input) {
        if (!StringUtils.hasText(input)) {
            return "";
        }
        
        return input.replace("&", "&amp;")
                    .replace("<", "&lt;")
                    .replace(">", "&gt;")
                    .replace("\"", "&quot;")
                    .replace("'", "&#39;");
    }

    // Méthode utilitaire pour les templates
    public String translate(String key, Object... args) {
        return getMessage(key, args);
    }
}