package com.module.auth.security;

import com.module.auth.repository.UserRepository;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;
import org.springframework.util.AntPathMatcher;

import java.io.IOException;
import java.util.Arrays;
import java.util.List;

@Component
public class JwtAuthFilter extends OncePerRequestFilter {

    private final JwtTokenProvider tokenProvider;
    private final UserRepository userRepository;
    private final AntPathMatcher pathMatcher = new AntPathMatcher();
    
    // List of endpoints to skip authentication
    private final List<String> excludedEndpoints = Arrays.asList(
        "/api/auth/**",
        "/swagger-ui/**",
        "/v3/api-docs/**",
        "/swagger-resources/**",
        "/api/public/**"
    );

    public JwtAuthFilter(JwtTokenProvider tokenProvider, UserRepository userRepository) {
        this.tokenProvider = tokenProvider;
        this.userRepository = userRepository;
    }

    @Override
protected void doFilterInternal(HttpServletRequest request,
        HttpServletResponse response,
        FilterChain filterChain)
        throws ServletException, IOException {

    // 1. Skip pour les endpoints autorisés
    if (shouldNotFilter(request)) {
        filterChain.doFilter(request, response);
        return;
    }

    // 2. Vérifie la présence du header
    String header = request.getHeader("Authorization");
    if (header == null || !header.startsWith("Bearer ")) {
        filterChain.doFilter(request, response);
        return;
    }

    // 3. Traitement du token
    try {
        String token = header.substring(7);
        String username = tokenProvider.getUsernameFromToken(token);
        
        if (username != null && SecurityContextHolder.getContext().getAuthentication() == null) {
            userRepository.findByEmail(username).ifPresent(user -> {
                if (tokenProvider.validateToken(token, user)) {
                    // Crée l'authentification
                    CustomUserDetails userDetails = new CustomUserDetails(user);
                    UsernamePasswordAuthenticationToken authentication = 
                        new UsernamePasswordAuthenticationToken(
                            userDetails,
                            null,
                            userDetails.getAuthorities());
                    authentication.setDetails(new WebAuthenticationDetailsSource().buildDetails(request));
                    
                    // Injecte dans le contexte de sécurité
                    SecurityContextHolder.getContext().setAuthentication(authentication);
                }
            });
        }
    } catch (Exception ex) {
        logger.error("Erreur d'authentification JWT", ex);
    }

    filterChain.doFilter(request, response);
}

    @Override
    protected boolean shouldNotFilter(HttpServletRequest request) {
        return excludedEndpoints.stream()
            .anyMatch(pattern -> pathMatcher.match(pattern, request.getServletPath()));
    }
}