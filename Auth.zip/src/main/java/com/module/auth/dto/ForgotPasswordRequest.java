package com.module.auth.dto;

import lombok.Data;

// ForgotPasswordRequest.java
@Data
public class ForgotPasswordRequest {
    private String email;
}
