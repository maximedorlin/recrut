package com.module.auth.dto;

import lombok.Data;

// RefreshTokenRequest.java
@Data
public class RefreshTokenRequest {
    private String refreshToken;
}