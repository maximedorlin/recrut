package com.module.auth.dto;

import lombok.Data;

// ResetPasswordRequest.java
@Data
public class ResetPasswordRequest {
    private String token; // Token reçu par email
    private String newPassword;
    private String confirmPassword;
}
