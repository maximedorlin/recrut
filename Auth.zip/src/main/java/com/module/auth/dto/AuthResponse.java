// package com.module.auth.dto;

// import lombok.Data;
// import java.util.UUID;

// @Data
// public class AuthResponse {
//     private String token;
//     private UUID userId;
//     private String email;
//     private String firstName;
//     private String lastName;
//     private String groupName;
//     private Long sessionId;

//     public AuthResponse(String token, 
//                        UUID userId, 
//                        String email, 
//                        String firstName, 
//                        String lastName, 
//                        String groupName, 
//                        Long sessionId) {
//         this.token = token;
//         this.userId = userId;
//         this.email = email;
//         this.firstName = firstName;
//         this.lastName = lastName;
//         this.groupName = groupName;
//         this.sessionId = sessionId;
//     }
// }

package com.module.auth.dto;

import java.util.UUID;

import lombok.Data;

@Data
public class AuthResponse {
    private String accessToken;
    private String refreshToken;

    public AuthResponse(String accessToken, String refreshToken) {
        this.accessToken = accessToken;
        this.refreshToken = refreshToken;

    }

    // Ajoutez ce constructeur si nécessaire pour la compatibilité
    public AuthResponse(String accessToken, UUID userId, String firstName,
            String lastName, String email, String phoneNumber, Long expiresIn) {
        // Implémentez selon vos besoins
    }
}