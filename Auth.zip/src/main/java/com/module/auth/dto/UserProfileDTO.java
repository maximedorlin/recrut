package com.module.auth.dto;

import java.util.UUID;

import lombok.Data;

@Data
public class UserProfileDTO {
    private UUID id;
    private String email;
    private String firstName;
    private String lastName;
    private String phoneNumber;
    // ... autres champs nécessaires
}
