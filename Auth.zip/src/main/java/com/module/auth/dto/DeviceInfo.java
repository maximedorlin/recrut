package com.module.auth.dto;

import lombok.Data;

@Data
public class DeviceInfo {
    private String platform;
    private String appName;
    private String appVersion;
    private String appCodeName;
    private String userAgent;
}
