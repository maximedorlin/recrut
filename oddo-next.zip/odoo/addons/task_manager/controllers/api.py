from odoo import http
from odoo.http import request
import json


class CORSController(http.Controller):
    @http.route(
        "/api/<path:path>", type="http", auth="none", methods=["OPTIONS"], csrf=False
    )
    def api_options_handler(self, **kwargs):
        headers = {
            "Access-Control-Allow-Origin": "*",
            "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
            "Access-Control-Allow-Headers": "Content-Type, Authorization",
            "Access-Control-Max-Age": "86400",
        }
        return request.make_response("", headers=headers)

    @http.route(
        "/web/session/authenticate",
        type="http",
        auth="none",
        methods=["OPTIONS"],
        csrf=False,
    )
    def web_session_options_handler(self, **kwargs):
        headers = {
            "Access-Control-Allow-Origin": "*",
            "Access-Control-Allow-Methods": "POST, OPTIONS",
            "Access-Control-Allow-Headers": "Content-Type, Authorization",
            "Access-Control-Max-Age": "86400",
        }
        return request.make_response("", headers=headers)


class TaskAPI(http.Controller):

    def _cors_headers(self):
        """Add CORS headers to responses."""
        return {
            "Access-Control-Allow-Origin": "*",
            "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
            "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Requested-With",
            "Access-Control-Max-Age": "86400",
        }

    @http.route("/api/tasks", type="json", auth="user", methods=["GET"], csrf=False)
    def get_tasks(self, **kwargs):
        """Retrieve all tasks."""
        try:
            filters = kwargs.get("filters", {})
            tasks = request.env["task.manager"].get_tasks_api(filters)
            return request.make_response(
                {
                    "success": True,
                    "data": tasks,
                    "message": "Tasks retrieved successfully.",
                },
                headers=self._cors_headers(),
            )
        except Exception as e:
            return request.make_response(
                {
                    "success": False,
                    "error": str(e),
                    "message": "Error retrieving tasks.",
                },
                headers=self._cors_headers(),
            )

    @http.route("/api/tasks", type="json", auth="user", methods=["POST"], csrf=False)
    def create_task(self, **kwargs):
        """Create a new task."""
        try:
            data = kwargs
            task = request.env["task.manager"].create(
                {
                    "username": data.get("username"),
                    "description": data.get("description", ""),
                    "priority": data.get("priority", "medium"),
                    "status": data.get("status", "todo"),
                    "due_date": data.get("due_date"),
                    "assigned_to": data.get("assigned_to"),
                }
            )
            return request.make_response(
                {
                    "success": True,
                    "data": {
                        "id": task.id,
                        "username": task.username,
                        "description": task.description,
                        "priority": task.priority,
                        "status": task.status,
                    },
                    "message": "Task created successfully.",
                },
                headers=self._cors_headers(),
            )
        except Exception as e:
            return request.make_response(
                {
                    "success": False,
                    "error": str(e),
                    "message": "Error creating task.",
                },
                headers=self._cors_headers(),
            )

    @http.route(
        "/api/tasks/<int:task_id>",
        type="json",
        auth="user",
        methods=["PUT"],
        csrf=False,
    )
    def update_task(self, task_id, **kwargs):
        """Update a task."""
        try:
            task = request.env["task.manager"].browse(task_id)
            if not task.exists():
                return request.make_response(
                    {"success": False, "message": "Task not found."},
                    headers=self._cors_headers(),
                )

            update_vals = {
                field: kwargs[field]
                for field in [
                    "username",
                    "description",
                    "priority",
                    "status",
                    "due_date",
                    "assigned_to",
                ]
                if field in kwargs
            }

            task.write(update_vals)
            return request.make_response(
                {"success": True, "message": "Task updated successfully."},
                headers=self._cors_headers(),
            )
        except Exception as e:
            return request.make_response(
                {
                    "success": False,
                    "error": str(e),
                    "message": "Error updating task.",
                },
                headers=self._cors_headers(),
            )

    @http.route(
        "/api/tasks/<int:task_id>",
        type="json",
        auth="user",
        methods=["DELETE"],
        csrf=False,
    )
    def delete_task(self, task_id):
        """Delete a task."""
        try:
            task = request.env["task.manager"].browse(task_id)
            if not task.exists():
                return request.make_response(
                    {"success": False, "message": "Task not found."},
                    headers=self._cors_headers(),
                )

            task.unlink()
            return request.make_response(
                {"success": True, "message": "Task deleted successfully."},
                headers=self._cors_headers(),
            )
        except Exception as e:
            return request.make_response(
                {
                    "success": False,
                    "error": str(e),
                    "message": "Error deleting task.",
                },
                headers=self._cors_headers(),
            )

    @http.route(
        "/web/session/authenticate",
        type="json",
        auth="none",
        methods=["POST"],
        csrf=False,
    )
    def login(self, **kwargs):
        """Authenticate a user."""
        try:
            params = kwargs.get("params", {})
            username = params.get("login")  # "login" instead of "username"
            password = params.get("password")
            db = params.get("db")

            if not username or not password:
                return request.make_response(
                    {
                        "success": False,
                        "message": "Username and password are required.",
                    },
                    headers=self._cors_headers(),
                )

            uid = request.session.authenticate(db, username, password)
            if uid:
                user = request.env["res.users"].browse(uid)
                return request.make_response(
                    {
                        "success": True,
                        "data": {
                            "user_id": uid,
                            "username": user.name,
                            "email": user.email,
                        },
                        "message": "Login successful.",
                    },
                    headers=self._cors_headers(),
                )
            else:
                return request.make_response(
                    {"success": False, "message": "Invalid credentials."},
                    headers=self._cors_headers(),
                )

        except Exception as e:
            return request.make_response(
                {
                    "success": False,
                    "error": str(e),
                    "message": "Error during login.",
                },
                headers=self._cors_headers(),
            )

    @http.route("/api/register", type="json", auth="none", methods=["POST"], csrf=False)
    def register_user(self, **kwargs):
        """Create a new user via API."""
        try:
            username = kwargs.get("username")
            email = kwargs.get("email")
            password = kwargs.get("password")

            if not (username and email and password):
                return request.make_response(
                    {
                        "success": False,
                        "message": "All fields (username, email, password) are required.",
                    },
                    headers=self._cors_headers(),
                )

            existing_user = (
                request.env["res.users"].sudo().search([("login", "=", email)], limit=1)
            )
            if existing_user:
                return request.make_response(
                    {
                        "success": False,
                        "message": "A user with this email already exists.",
                    },
                    headers=self._cors_headers(),
                )

            new_user = (
                request.env["res.users"]
                .sudo()
                .create(
                    {
                        "username": username,
                        "login": email,
                        "email": email,
                        "password": password,
                    }
                )
            )

            return request.make_response(
                {
                    "success": True,
                    "message": "User registered successfully.",
                    "data": {
                        "id": new_user.id,
                        "username": new_user.username,
                        "email": new_user.email,
                    },
                },
                headers=self._cors_headers(),
            )

        except Exception as e:
            return request.make_response(
                {
                    "success": False,
                    "error": str(e),
                    "message": "Error during user registration.",
                },
                headers=self._cors_headers(),
            )
