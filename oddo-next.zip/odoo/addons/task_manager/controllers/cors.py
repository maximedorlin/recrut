from odoo import http
from odoo.http import request


class CORSController(http.Controller):
    # CORS pour toutes les routes sous /api/
    @http.route(
        "/api/<path:path>", type="http", auth="none", methods=["OPTIONS"], csrf=False
    )
    def api_options_handler(self, **kwargs):
        headers = [
            ("Access-Control-Allow-Origin", "*"),
            ("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS"),
            ("Access-Control-Allow-Headers", "Content-Type, Authorization"),
            ("Access-Control-Max-Age", "86400"),
        ]
        return request.make_response("", headers=headers)

    # CORS pour la route /web/session/authenticate
    @http.route(
        "/web/session/authenticate",
        type="http",
        auth="none",
        methods=["OPTIONS"],
        csrf=False,
    )
    def web_session_options_handler(self, **kwargs):
        headers = [
            ("Access-Control-Allow-Origin", "*"),
            ("Access-Control-Allow-Methods", "POST, OPTIONS"),
            ("Access-Control-Allow-Headers", "Content-Type, Authorization"),
            ("Access-Control-Max-Age", "86400"),
        ]
        return request.make_response("", headers=headers)
