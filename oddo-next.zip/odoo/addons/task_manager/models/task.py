from odoo import models, fields, api
from datetime import datetime


class Task(models.Model):
    _name = "task.manager"
    _description = "Task Manager"
    _order = "create_date desc"

    name = fields.Char("Titre", required=True)
    description = fields.Text("Description")
    priority = fields.Selection(
        [("low", "Basse"), ("medium", "Moyenne"), ("high", "Haute")],
        default="medium",
        string="Priorité",
    )
    status = fields.Selection(
        [("todo", "À faire"), ("in_progress", "En cours"), ("done", "Terminé")],
        default="todo",
        string="Statut",
    )
    due_date = fields.Datetime("Date d'échéance")
    assigned_to = fields.Many2one("res.users", "Assigné à")
    create_date = fields.Datetime("Date de création", default=fields.Datetime.now)

    @api.model
    def get_tasks_api(self, filters=None):
        """Récupère les tâches avec filtres optionnels"""
        domain = []
        if filters:
            if filters.get("status"):
                domain.append(("status", "=", filters["status"]))
            if filters.get("priority"):
                domain.append(("priority", "=", filters["priority"]))
            if filters.get("assigned_to"):
                domain.append(("assigned_to", "=", filters["assigned_to"]))

        tasks = self.search(domain)
        return [
            {
                "id": task.id,
                "name": task.name,
                "description": task.description,
                "priority": task.priority,
                "status": task.status,
                "due_date": task.due_date.isoformat() if task.due_date else None,
                "assigned_to": task.assigned_to.name if task.assigned_to else None,
                "create_date": (
                    task.create_date.isoformat() if task.create_date else None
                ),
            }
            for task in tasks
        ]
