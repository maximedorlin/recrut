import header_avatar from "@/images/header-avatar.svg";
import logo_cud_tranparent from "@/images/logo_cud_tranparent.png";
import admin from "@/images/icons/admin-with-cogwheels.svg";
import city from "@/images/icons/city-block.svg";
import health from "@/images/icons/health-insurance-round.svg";
import lighting from "@/images/icons/lighting-3.svg";
import road from "@/images/icons/meandering-road-with-trees-at-sides.svg";
import recycle from "@/images/icons/recycle.svg";
import errorpayment from "@/images/errorpayment.webp";
import unauthorize from "@/images/unauthorize.png";
import empty from "@/images/empty.png";
import undraw_not_found from "@/images/undraw_not-found.svg";
import undraw_unauthorized from "@/images/undraw_unauthorized.svg";
import internal_server_error from "@/images/internal_server_error.svg";
import bad_request from "@/images/bad_request.svg";
import base from "@/images/basemap/base.png";
import pdu from "@/images/basemap/pdu.png";
import pos from "@/images/basemap/pos.png";
import arrow_locate from "@/images/arrow_locate.svg";

import mission from '@/assets/mission.jpg';
import team from '@/assets/team.jpg';
import values from '@/assets/values.jpg';

const IMAGES = {
  logo_cud_tranparent,
  header_avatar,
  admin,
  city,
  health,
  lighting,
  road,
  recycle,
  unauthorize,
  errorpayment,
  undraw_not_found,
  undraw_unauthorized,
  internal_server_error,
  bad_request,
  empty,
  base,
  pdu,
  pos,
  arrow_locate,
  mission,
  team,
  values
};

export { IMAGES };
