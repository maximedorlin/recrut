export const RequiredMark = () => {
  return <span className="text-red-500 ml-1">*</span>;
};
