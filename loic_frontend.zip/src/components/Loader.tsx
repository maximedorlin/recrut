"use client";
import React from "react";

const Loader = () => {
  return (
    <div className="w-full p-10 bg-white">
      <div className="loader__ss">
        <div className="justify-content-center jimu-primary-loading"></div>
      </div>
    </div>
  );
};

export default Loader;
