import React from "react";

const StatusDone = () => {
  return (
    <div>
      <svg
        width="311"
        height="282"
        viewBox="0 0 311 282"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
      >
        <rect width="311" height="282" rx="10" fill="#FFFCCF" />
        <circle cx="155" cy="141" r="100" fill="#FF0000" />
        <circle cx="155" cy="141" r="78" fill="white" />
        <path
          d="M145.266 177.91L107.514 136.184C107.436 136.098 107.545 135.97 107.643 136.033L145.278 160.471C145.319 160.498 145.372 160.491 145.405 160.457L205 98L145.421 177.902C145.383 177.953 145.308 177.957 145.266 177.91Z"
          fill="#00642C"
          stroke="#CCCCCC"
          stroke-linecap="round"
        />
      </svg>
    </div>
  );
};

export default StatusDone;
