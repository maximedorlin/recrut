import React from "react";

const CustumBuilding: React.FC = () => {
  return (
    <div>
      <svg
        width="76"
        height="106"
        viewBox="0 0 76 106"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
      >
        <path
          d="M46.4169 0L0 14.5931V105.9H46.4169V0Z"
          fill="url(#paint0_linear_2477_8136)"
          fill-opacity="0.5"
        />
        <path
          d="M75.2536 53.9974L46.2285 39.4043V105.901H75.2536V53.9974Z"
          fill="url(#paint1_linear_2477_8136)"
          fill-opacity="0.5"
        />
        <path
          d="M55.5365 60.6055H48.6875V66.7215H55.5365V60.6055Z"
          fill="white"
        />
        <path
          d="M55.5365 71.2627H48.6875V77.3788H55.5365V71.2627Z"
          fill="white"
        />
        <path
          d="M55.5365 81.9209H48.6875V88.037H55.5365V81.9209Z"
          fill="white"
        />
        <path
          d="M55.5365 92.582H48.6875V98.6981H55.5365V92.582Z"
          fill="white"
        />
        <path
          d="M68.2187 60.6055H61.3672V66.7215H68.2187V60.6055Z"
          fill="white"
        />
        <path
          d="M68.2187 71.2627H61.3672V77.3788H68.2187V71.2627Z"
          fill="white"
        />
        <path
          d="M68.2187 81.9209H61.3672V88.037H68.2187V81.9209Z"
          fill="white"
        />
        <path
          d="M68.2187 92.582H61.3672V98.6981H68.2187V92.582Z"
          fill="white"
        />
        <path
          d="M38.9757 22.1396H6.83594V26.4389H38.9757V22.1396Z"
          fill="white"
        />
        <path
          d="M38.9757 32.3027H6.83594V36.602H38.9757V32.3027Z"
          fill="white"
        />
        <path
          d="M38.9757 42.4668H6.83594V46.766H38.9757V42.4668Z"
          fill="white"
        />
        <path
          d="M38.9757 52.6299H6.83594V56.9291H38.9757V52.6299Z"
          fill="white"
        />
        <path
          d="M38.9757 62.7939H6.83594V67.0932H38.9757V62.7939Z"
          fill="white"
        />
        <path
          d="M38.9757 72.9561H6.83594V77.2553H38.9757V72.9561Z"
          fill="white"
        />
        <path
          d="M38.9757 83.1211H6.83594V87.4203H38.9757V83.1211Z"
          fill="white"
        />
        <path
          d="M38.9757 93.2842H6.83594V97.5834H38.9757V93.2842Z"
          fill="white"
        />
        <defs>
          <linearGradient
            id="paint0_linear_2477_8136"
            x1="3.6025"
            y1="13.577"
            x2="45.8175"
            y2="14.4607"
            gradientUnits="userSpaceOnUse"
          >
            <stop stop-color="#00642C" />
            <stop offset="0.528177" stop-color="#E41E2F" />
            <stop offset="1" stop-color="#EEEE00" />
          </linearGradient>
          <linearGradient
            id="paint1_linear_2477_8136"
            x1="48.4812"
            y1="47.9295"
            x2="74.8789"
            y2="48.4798"
            gradientUnits="userSpaceOnUse"
          >
            <stop stop-color="#00642C" />
            <stop offset="0.528177" stop-color="#E41E2F" />
            <stop offset="1" stop-color="#EEEE00" />
          </linearGradient>
        </defs>
      </svg>
    </div>
  );
};

export default CustumBuilding;