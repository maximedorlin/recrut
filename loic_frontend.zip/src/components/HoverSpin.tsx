import React from "react";

const HoverSpin = () => {
  return (
    <div className="spinner-box bg-black p-4">
      <div className="card-spinner w-[400px] h-[200px] bg-orange-500 rounded-lg">
        <span></span>
        <span></span>
        <span></span>
        <span></span>
      </div>
    </div>
  );
};

export default HoverSpin;
