

export interface Evaluation{
    
}