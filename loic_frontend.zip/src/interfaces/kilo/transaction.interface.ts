

export interface Transaction{

}