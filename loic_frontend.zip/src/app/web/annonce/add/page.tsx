import React from "react";
import CreerAnnonce from "../form";
// import UrlGuard from "@/lib/UrlGuard";

const AddParticipant: React.FC = () => {
  return (
    // <UrlGuard permission="add_participant">
      <CreerAnnonce />
    // </UrlGuard>
  );
};
export default AddParticipant;
