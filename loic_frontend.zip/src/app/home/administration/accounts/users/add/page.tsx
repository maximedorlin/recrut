import React from "react";
import UserForm from "../form";
// import UrlGuard from "@/lib/UrlGuard";

const AddUser: React.FC = () => {
  return (
    // <UrlGuard permission="add_user">
      <UserForm />
    // </UrlGuard>
  );
};
export default AddUser;
