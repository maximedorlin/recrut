import React from "react";
import GroupForm from "../form";
// import UrlGuard from "@/lib/UrlGuard";

const AddGroup: React.FC = () => {
  return (
    // <UrlGuard permission="add_group">
      // {" "}
      <GroupForm />
    // </UrlGuard>
  );
};
export default AddGroup;
