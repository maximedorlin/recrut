import React from "react";
import PersonnelForm from "../form";
// import UrlGuard from "@/lib/UrlGuard";

const AddPersonnel: React.FC = () => {
  return (
    // <UrlGuard permission="add_personnel">
      <PersonnelForm />
    // </UrlGuard>
  );
};
export default AddPersonnel;
