import React from "react";
import ParticipantsForm from "../form";
// import UrlGuard from "@/lib/UrlGuard";

const AddParticipant: React.FC = () => {
  return (
    // <UrlGuard permission="add_participant">
      <ParticipantsForm />
    // </UrlGuard>
  );
};
export default AddParticipant;
