
http://localhost:8080/swagger-ui.html

http://localhost:8080/swagger-ui/index.html


@JsonIgnore

@JsonBackReference



FROM maven:3.9.5-eclipse-temurin-21

WORKDIR /app

COPY pom.xml .
RUN mvn dependency:go-offline

COPY src ./src
RUN mvn package -DskipTests

ENTRYPOINT ["java", "-jar", "target/your-app-name.jar"]



Pour la production locale :

bash
docker-compose -f docker-compose.prod.yml build
docker-compose -f docker-compose.prod.yml up -d
Pour le déploiement :

bash
# Build et push de l'image
docker build -t your-registry/springboot-prod:latest -f Dockerfile.prod .
docker push your-registry/springboot-prod:latest

# Déploiement avec variables d'environnement
export DB_PASSWORD=StrongPassword123!
export DB_USER=deploy_admin
export TAG=v1.2.0

docker-compose -f docker-compose.deploy.yml up -d
Arrêt et nettoyage :

bash
# Production locale
docker-compose -f docker-compose.prod.yml down -v

# Déploiement
docker-compose -f docker-compose.deploy.yml down -v









Initiation du paiement :

bash
POST /api/paiements/initiate
{
  "transactionId": 123,
  "methode": "MOMO",
  "montant": 15000.0,
  "phoneNumber": "+237699999999"
}
Réponse :

json
{
  "id": 456,
  "referencePaiement": "MOMO_1a2b3c4d5e6f",
  "statut": "en_attente",
  "informationsSupplementaires": "{\"phone\":\"+237699999999\"}"
}
Webhook de confirmation :

bash
POST /api/paiements/webhook/momo
X-Signature: hmac_signature
{
  "reference": "MOMO_1a2b3c4d5e6f",
  "status": "SUCCESSFUL",
  "amount": 15000.0,
  "transactionId": "MOMO_TRX_123456"
}

# ajouter un utilisateur

{
  "nom": "Dupont",
  "prenom": "Jean",
  "email": "jean.dupont@example.com",
  "password": "MotDePasse123!",
  "telephone": "+33612345678",
  "adresse": "123 Rue de la Paix",
  "ville": "Paris",
  "pays": "France",
  "codePostal": "75001"
}

Créer une annonce pour un utilisateur (POST /api/users/{userId}/annonces)
json
{
  "titre": "Vélo de course",
  "description": "Vélo peu utilisé, état parfait",
  "prix": 250.00
}

Mise à jour partielle (PATCH /api/users/{id})
json
{
  "ville": "Lyon",
  "codePostal": "69002",
  "verifie": true
}

Méthode	Endpoint	Description
GET	/api/users	Liste tous les utilisateurs
GET	/api/users/{id}	Détails d'un utilisateur
POST	/api/users	Crée un nouvel utilisateur
PUT	/api/users/{id}	Met à jour un utilisateur
PATCH	/api/users/{id}	Mise à jour partielle
DELETE	/api/users/{id}	Supprime un utilisateur
GET	/api/users/{userId}/annonces	Annonces d'un utilisateur
POST	/api/users/{userId}/annonces	Crée une annonce pour l'utilisateur
DELETE	/api/users/{userId}/annonces	Supprime toutes les annonces
GET	/api/users/{userId}/transactions	Transactions d'un utilisateur
DELETE	/api/users/{userId}/transactions	Supprime toutes les transactions










# ajouter une annonce 

{
  "utilisateur": {
    "id": 1
  },
  "titre": "Livraison de colis à Douala",
  "description": "Je dois envoyer un colis de Yaoundé à Douala. Contenu fragile.",
  "categorie": "electronique",
  "prix": 5000.0,
  "devise": "XOF",
  "poids": 2.5,
  "dimensions": "30x20x10 cm",
  "villeDepart": "Yaoundé",
  "villeArrivee": "Douala",
  "dateDepartPrevu": "2025-08-01",
  "dateArriveePrevu": "2025-08-03",
  "statut": "disponible"
}

Mettre à jour partiellement une annonce (PATCH /api/annonces/{id})

json
{
  "prix": 1100.00,
  "statut": "en_cours"
}

{
  "montant": 1100.00,
  "devise": "XOF"
  // autres propriétés de transaction
}



POST /api/auth/login
Content-Type: application/json

{
"email": "admin@kilotogo.com",
"password": "adminPassword"
}




http://localhost:8080/login#/user-controller/createUser