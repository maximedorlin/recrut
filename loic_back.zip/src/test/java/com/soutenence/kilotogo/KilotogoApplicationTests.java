package com.soutenence.kilotogo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KilotogoApplicationTests {

    @Test
    void contextLoads() {
    }

}
