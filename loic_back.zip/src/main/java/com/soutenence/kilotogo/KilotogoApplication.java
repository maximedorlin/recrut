package com.soutenence.kilotogo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KilotogoApplication {

    public static void main(String[] args) {
        SpringApplication.run(KilotogoApplication.class, args);
    }

}
