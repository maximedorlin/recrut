package com.soutenence.kilotogo.controller;

import com.soutenence.kilotogo.entity.Evaluation;
import com.soutenence.kilotogo.service.EvaluationService;
import org.springframework.data.domain.Page;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/evaluations")
public class EvaluationController {
    private final EvaluationService evaluationService;

    public EvaluationController(EvaluationService evaluationService) {
        this.evaluationService = evaluationService;
    }

    @GetMapping
    public List<Evaluation> getAllEvaluations() {
        return evaluationService.getAllEvaluations();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Evaluation> getEvaluationById(@PathVariable Long id) {
        Optional<Evaluation> evaluation = evaluationService.getEvaluationById(id);
        return evaluation.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.notFound().build());
    }

    @PostMapping
    public Evaluation createEvaluation(@RequestBody Evaluation evaluation) {
        return evaluationService.createEvaluation(evaluation);
    }

    @PutMapping("/{id}")
    public Evaluation updateEvaluation(@PathVariable Long id, @RequestBody Evaluation evaluationDetails) {
        return evaluationService.updateEvaluation(id, evaluationDetails);
    }

    @DeleteMapping("/{id}")
    public void deleteEvaluation(@PathVariable Long id) {
        evaluationService.deleteEvaluation(id);
    }

    @PatchMapping("/{id}")
    public Evaluation partialUpdateEvaluation(@PathVariable Long id, @RequestBody Evaluation evaluationUpdates) {
        return evaluationService.partialUpdateEvaluation(id, evaluationUpdates);
    }
    private static final int DEFAULT_PAGE_SIZE = 10;

    @GetMapping("/paginated")
    public Page<Evaluation> getEvaluationsPaginated(
            @RequestParam(value = "page", defaultValue = "0") int page,
            @RequestParam(value = "size", required = false) Integer size) {

        int pageSize = size != null ? size : DEFAULT_PAGE_SIZE;

        // Validation
        if (page < 0) throw new IllegalArgumentException("Invalid page number");
        if (size != null && size <= 0) throw new IllegalArgumentException("Invalid page size");

        return evaluationService.getAllEvaluationPaginated(page, pageSize);
    }
}
