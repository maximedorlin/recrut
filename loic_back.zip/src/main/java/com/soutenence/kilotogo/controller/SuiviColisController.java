package com.soutenence.kilotogo.controller;

import com.soutenence.kilotogo.entity.SuiviColis;
import com.soutenence.kilotogo.service.SuiviColisService;
import org.springframework.data.domain.Page;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/suiviColis")
public class SuiviColisController {
    private final SuiviColisService suiviColisService;

    public SuiviColisController(SuiviColisService suiviColisService) {
        this.suiviColisService = suiviColisService;
    }

    @GetMapping
    public List<SuiviColis> getAllSuiviColis() {
        return suiviColisService.getAllSuiviColis();
    }

    @GetMapping("/{id}")
    public ResponseEntity<SuiviColis> getSuiviColisById(@PathVariable Long id) {
        Optional<SuiviColis> suiviColis = suiviColisService.getSuiviColisById(id);
        return suiviColis.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.notFound().build());
    }

    @PostMapping
    public SuiviColis createSuiviColis(@RequestBody SuiviColis suiviColis) {
        return suiviColisService.createSuiviColis(suiviColis);
    }

    @PutMapping("/{id}")
    public SuiviColis updateSuiviColis(@PathVariable Long id, @RequestBody SuiviColis suiviColisDetails) {
        return suiviColisService.updateSuiviColis(id, suiviColisDetails);
    }

    @DeleteMapping("/{id}")
    public void deleteSuiviColis(@PathVariable Long id) {
        suiviColisService.deleteSuiviColis(id);
    }

    @PatchMapping("/{id}")
    public SuiviColis partialUpdateSuiviColis(@PathVariable Long id, @RequestBody SuiviColis suiviColisUpdates) {
        return suiviColisService.partialUpdateSuiviColis(id, suiviColisUpdates);
    }

    private static final int DEFAULT_PAGE_SIZE = 10;

    @GetMapping("/paginated")
    public Page<SuiviColis> getSuiviColisPaginated(
            @RequestParam(value = "page", defaultValue = "0") int page,
            @RequestParam(value = "size", required = false) Integer size) {

        int pageSize = size != null ? size : DEFAULT_PAGE_SIZE;

        // Validation
        if (page < 0) throw new IllegalArgumentException("Invalid page number");
        if (size != null && size <= 0) throw new IllegalArgumentException("Invalid page size");

        return suiviColisService.getAllSuiviColisPaginated(page, pageSize);
    }

}
