package com.soutenence.kilotogo.controller;

import com.soutenence.kilotogo.entity.Message;
import com.soutenence.kilotogo.service.MessageService;
import org.springframework.data.domain.Page;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/messages")
public class MessageController {
    private final MessageService messageService;

    public MessageController(MessageService messageService) {
        this.messageService = messageService;
    }

    @GetMapping
    public List<Message> getAllMessages() {
        return messageService.getAllMessages();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Message> getMessageById(@PathVariable Long id) {
        Optional<Message> message = messageService.getMessageById(id);
        return message.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.notFound().build());
    }

    @PostMapping
    public Message createMessage(@RequestBody Message message) {
        return messageService.createMessage(message);
    }

    @PutMapping("/{id}")
    public Message updateMessage(@PathVariable Long id, @RequestBody Message messageDetails) {
        return messageService.updateMessage(id, messageDetails);
    }

    @DeleteMapping("/{id}")
    public void deleteMessage(@PathVariable Long id) {
        messageService.deleteMessage(id);
    }

    @PatchMapping("/{id}")
    public Message partialUpdateMessage(@PathVariable Long id, @RequestBody Message messageUpdates) {
        return messageService.partialUpdateMessage(id, messageUpdates);
    }

    private static final int DEFAULT_PAGE_SIZE = 10;

    @GetMapping("/paginated")
    public Page<Message> getMessagesPaginated(
            @RequestParam(value = "page", defaultValue = "0") int page,
            @RequestParam(value = "size", required = false) Integer size) {

        int pageSize = size != null ? size : DEFAULT_PAGE_SIZE;

        // Validation
        if (page < 0) throw new IllegalArgumentException("Invalid page number");
        if (size != null && size <= 0) throw new IllegalArgumentException("Invalid page size");

        return messageService.getAllMessagePaginated(page, pageSize);
    }
}