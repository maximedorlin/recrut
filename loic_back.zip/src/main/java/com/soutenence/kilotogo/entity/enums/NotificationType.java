package com.soutenence.kilotogo.entity.enums;

public enum NotificationType {
    message, transaction, paiement, annonce, evaluation
}
