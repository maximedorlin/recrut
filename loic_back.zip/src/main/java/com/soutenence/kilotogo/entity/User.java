package com.soutenence.kilotogo.entity;

import lombok.*;
import jakarta.persistence.*;
import java.time.LocalDateTime;
import java.util.Collection;
import java.util.List;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import com.soutenence.kilotogo.entity.enums.UserStatus;

@Entity
@Table(name = "Utilisateur")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class User implements UserDetails{
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String nom;

    @Column(nullable = false)
    private String prenom;

    @Column(unique = true, nullable = false)
    private String email;

    @Column(name = "mot_de_passe", nullable = false)
    private String password;

    @Column(unique = true, nullable = false)
    private String telephone;

    private String adresse;
    private String ville;
    private String pays;

    @Column(name = "code_postal")
    private String codePostal;

    @Column(name = "date_inscription")
    private LocalDateTime inscriptionDate = LocalDateTime.now();

    @Enumerated(EnumType.STRING)
    private UserStatus statut = UserStatus.actif;

    @Column(name = "score_reputation")
    private Double reputationScore = 5.0;

    @Column(name = "photo_profil")
    private String profilePhoto;

    private Boolean verifie = false;

    @Column(name = "derniere_connexion")
    private LocalDateTime lastLogin;

    @OneToMany(mappedBy = "utilisateur", cascade = CascadeType.ALL)
    private List<Annonce> annonces;

    @OneToMany(mappedBy = "acheteur", cascade = CascadeType.ALL)
    private List<Transaction> achats;

    @OneToMany(mappedBy = "vendeur", cascade = CascadeType.ALL)
    private List<Transaction> ventes;

@Override
    public Collection<? extends GrantedAuthority> getAuthorities() {
        return List.of(new SimpleGrantedAuthority("ROLE_USER"));
    }

    @Override
    public String getUsername() {
        return email;
    }

    @Override
    public boolean isAccountNonExpired() {
        return true;
    }

    @Override
    public boolean isAccountNonLocked() {
        return statut != UserStatus.bloque;
    }

    @Override
    public boolean isCredentialsNonExpired() {
        return true;
    }

    @Override
    public boolean isEnabled() {
        return statut == UserStatus.actif;
    }

}

