package com.soutenence.kilotogo.entity.enums;

public enum PaiementMethode {
    MOMO, OM, PayPal, carte_credit, especes
}