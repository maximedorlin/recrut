package com.soutenence.kilotogo.entity.enums;

public enum UserStatus {
    actif, inactif, suspendu, bloque
}
