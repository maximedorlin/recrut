package com.soutenence.kilotogo.entity.enums;

public enum ColisStatus {
    preparation, en_transit, en_livraison, livre, probleme
}
