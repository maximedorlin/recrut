package com.soutenence.kilotogo.entity.enums;

public enum AnnonceStatus {
    disponible, reserve, expedie, livre, annule
}