package com.soutenence.kilotogo.entity.enums;

public enum TransactionStatus {
    initie, en_attente, paye, annulee, remboursee
}
