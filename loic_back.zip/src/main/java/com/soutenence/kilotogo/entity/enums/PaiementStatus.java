package com.soutenence.kilotogo.entity.enums;

public enum PaiementStatus {
    en_attente,
    complete,
    echec
}