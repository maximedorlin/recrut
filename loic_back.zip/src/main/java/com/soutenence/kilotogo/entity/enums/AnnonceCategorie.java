package com.soutenence.kilotogo.entity.enums;

public enum AnnonceCategorie {
    electronique, vetements, meubles, livres, autres
}