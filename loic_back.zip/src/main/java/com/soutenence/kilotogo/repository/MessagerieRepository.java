package com.soutenence.kilotogo.repository;


import com.soutenence.kilotogo.entity.Messagerie;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MessagerieRepository extends JpaRepository<Messagerie, Long> {
    Page<Messagerie> findAll(Pageable pageable);
}
