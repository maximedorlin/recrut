package com.soutenence.kilotogo.service;

import com.soutenence.kilotogo.dto.PaymentRequestDTO;
import com.soutenence.kilotogo.entity.Paiement;
import org.springframework.data.domain.Page;

import java.util.Map;

public interface PaymentService {
    Paiement initierPaiement(PaymentRequestDTO request);
    void processWebhook(String provider, Map<String, Object> payload);
    String calculateHMAC(String data, String secret);

    Page<Paiement> getAllPaiementsPaginated(int page, int size);
}