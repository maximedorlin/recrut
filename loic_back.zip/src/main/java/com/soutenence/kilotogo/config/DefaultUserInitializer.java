package com.soutenence.kilotogo.config;

import com.soutenence.kilotogo.entity.User;
import com.soutenence.kilotogo.entity.enums.UserStatus;
import com.soutenence.kilotogo.repository.UserRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

@Component
public class DefaultUserInitializer implements CommandLineRunner {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;

    public DefaultUserInitializer(UserRepository userRepository, PasswordEncoder passwordEncoder) {
        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
    }

    @Override
    public void run(String... args) {
        createDefaultAdminIfNotExists();
    }

        private User createDefaultAdminIfNotExists() {
            String adminEmail = "admin@kilotogo.com";
            return userRepository.findByEmail(adminEmail).orElseGet(() -> {
                User admin = new User();
                admin.setNom("Admin");
                admin.setPrenom("Kilotogo");
                admin.setEmail(adminEmail);
                admin.setPassword(passwordEncoder.encode("adminPassword"));
                admin.setTelephone("+1234567890");
                admin.setAdresse("Siège Kilotogo");
                admin.setVille("Ville Admin");
                admin.setPays("Pays Admin");
                admin.setCodePostal("00000");
                admin.setStatut(UserStatus.actif);
                admin.setReputationScore(5.0);
                admin.setVerifie(true);
                User savedAdmin = userRepository.save(admin);
                System.out.println("Admin user created successfully");
                return savedAdmin;
            });

    }
}